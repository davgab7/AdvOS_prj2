#ifndef SHARED_MEM_H
#define SHARED_MEM_H


void async_call(char *filename, int pid);
void sync_call(char *filename, int pid);


#endif